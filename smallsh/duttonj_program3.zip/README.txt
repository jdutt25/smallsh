Jessica Dutton
OSU CS 344
Project 3 Smallsh

To run, navigate to the folder where it's located via command line and enter the following:

gcc -std=gnu99 -g -Wall -o smallsh smallsh.c 
./smallsh
