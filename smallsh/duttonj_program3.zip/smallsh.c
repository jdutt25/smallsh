/*
	Author:	Jessica Dutton
	Class:	OSU CS 344
	Last updated: 2/8/22
	Smallsh Main
*/

#include "smallsh.h"


/// <summary>
/// Main function
/// </summary>
/// <returns>0</returns>
int main()
{
	commandPrompt();
	return 0;
}
